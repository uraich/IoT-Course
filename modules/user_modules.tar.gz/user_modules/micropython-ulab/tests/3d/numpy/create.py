from ulab import numpy as np
print(sum(np.ones((3,2,4))))
