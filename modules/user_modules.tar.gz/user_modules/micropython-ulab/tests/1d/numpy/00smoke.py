from ulab import numpy as np

print(np.ones(3))
