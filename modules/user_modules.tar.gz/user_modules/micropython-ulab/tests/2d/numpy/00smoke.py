from ulab import numpy as np

print(np.eye(3))
