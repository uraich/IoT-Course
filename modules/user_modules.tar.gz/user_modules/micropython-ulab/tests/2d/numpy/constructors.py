from ulab import numpy as np

print(np.ones(3))
print(np.ones((2,3)))
print(np.zeros(3))
print(np.zeros((2,3)))
print(np.eye(3))
print(np.ones(1, dtype=np.int8))
print(np.ones(2, dtype=np.uint8))
print(np.ones(3, dtype=np.int16))
print(np.ones(4, dtype=np.uint16))
print(np.ones(5, dtype=np.float))
print(np.linspace(0, 1, 9))
