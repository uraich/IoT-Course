#ifndef __ST7735_H__
#define __ST7735_H__

#define ST_WIDTH 130
#define ST_HEIGHT 130
#define ST_BUFLEN 128

#define ST_NOP 0x0
#define ST_SWRESET 0x01
#define ST_RDDID 0x04
#define ST_RDDST 0x09

#define ST_SLPIN 0x10
#define ST_SLPOUT 0x11
#define ST_PTLON 0x12
#define ST_NORON 0x13

#define ST_INVOFF 0x20
#define ST_INVON 0x21
#define ST_DISPOFF 0x28
#define ST_DISPON 0x29
#define ST_CASET 0x2A
#define ST_RASET 0x2B
#define ST_RAMWR 0x2C
#define ST_RAMRD 0x2E

#define ST_COLMOD 0x3A
#define ST_MADCTL 0x36

#define ST_FRMCTR1 0xB1
#define ST_FRMCTR2 0xB2
#define ST_FRMCTR3 0xB3
#define ST_INVCTR 0xB4
#define ST_DISSET5 0xB6

#define ST_PWCTR1 0xC0
#define ST_PWCTR2 0xC1
#define ST_PWCTR3 0xC2
#define ST_PWCTR4 0xC3
#define ST_PWCTR5 0xC4
#define ST_VMCTR1 0xC5

#define ST_RDID1 0xDA
#define ST_RDID2 0xDB
#define ST_RDID3 0xDC
#define ST_RDID4 0xDD

#define ST_PWCTR6 0xFC

#define ST_GMCTRP1 0xE0
#define ST_GMCTRN1 0xE1

#define ST_COLOR( r, g, b) (((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3))
/*
#define ST_COLOR_BLACK ((uint32_t)ST_COLOR(0, 0, 0))
#define ST_COLOR_WHITE ((uint32_t)ST_COLOR(255, 255, 255))
#define ST_COLOR_RED ((uint32_t)ST_COLOR(255, 0, 0))
#define ST_COLOR_GREEN ((uint32_t)ST_COLOR(0, 255, 0))
#define ST_COLOR_BLUE ((uint32_t)ST_COLOR(0, 0, 255))
#define ST_COLOR_CYAN ((uint32_t)ST_COLOR(0, 255, 255))
#define ST_COLOR_YELLOW ((uint32_t)ST_COLOR(255, 255, 0))
#define ST_COLOR_PURPLE ((uint32_t)ST_COLOR(255, 0, 255))
#define ST_COLOR_GRAY ((uint32_t)ST_COLOR(128, 128, 128))
#define ST_COLOR_MAROON ((uint32_t)ST_COLOR(128, 0, 0))
#define ST_COLOR_NAVY ((uint32_t)ST_COLOR(0, 0, 128))
*/
// ==== Color definitions constants ================================
#define ST_COLOR_BLACK        ((uint32_t)ST_COLOR(   0,   0,   0 ))
#define ST_COLOR_NAVY         ((uint32_t)ST_COLOR(   0,   0, 128 ))
#define ST_COLOR_DARKGREEN    ((uint32_t)ST_COLOR(   0, 128,   0 ))
#define ST_COLOR_DARKCYAN     ((uint32_t)ST_COLOR(   0, 128, 128 ))
#define ST_COLOR_MAROON       ((uint32_t)ST_COLOR( 128,   0,   0 ))
#define ST_COLOR_PURPLE       ((uint32_t)ST_COLOR( 255,   0, 255 ))
#define ST_COLOR_OLIVE        ((uint32_t)ST_COLOR( 128, 128,   0 ))
#define ST_COLOR_LIGHTGREY    ((uint32_t)ST_COLOR( 192, 192, 192 ))
#define ST_COLOR_DARKGREY     ((uint32_t)ST_COLOR( 128, 128, 128 ))
#define ST_COLOR_BLUE         ((uint32_t)ST_COLOR(   0,   0, 255 ))
#define ST_COLOR_GREEN        ((uint32_t)ST_COLOR(   0, 255,   0 ))
#define ST_COLOR_CYAN         ((uint32_t)ST_COLOR(   0, 255, 255 ))
#define ST_COLOR_RED          ((uint32_t)ST_COLOR( 255,   0,   0 ))
#define ST_COLOR_MAGENTA      ((uint32_t)ST_COLOR( 255,   0, 255 ))
#define ST_COLOR_YELLOW       ((uint32_t)ST_COLOR( 255, 255,   0 ))
#define ST_COLOR_WHITE        ((uint32_t)ST_COLOR( 255, 255, 255 ))
#define ST_COLOR_ORANGE       ((uint32_t)ST_COLOR( 255, 164,   0 ))
#define ST_COLOR_GREENYELLOW  ((uint32_t)ST_COLOR( 172, 255,  44 ))
#define ST_COLOR_PINK         ((uint32_t)ST_COLOR( 255, 192, 202 ))
#define ST_COLOR_FOREST       ((uint32_t)ST_COLOR(   0, 128,   0 ))
// =================================================================

#endif /* __ST7735_H__ */
