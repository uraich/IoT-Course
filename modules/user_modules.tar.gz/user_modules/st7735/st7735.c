/*
 * This file is part of the micropython-usermod project, 
 *
 * https://github.com/v923z/micropython-usermod
 *
 * The MIT License (MIT)
 *
 * Copyright (c) 2020 Uli Raich
*/
    
#include <stdio.h>
#include "py/runtime.h"
#include "py/obj.h"
#include <math.h>

#include "py/builtin.h"
#include "py/mphal.h"
#include "modmachine.h"
#include "extmod/machine_spi.h"
#include "driver/gpio.h"

#include "font_petme128_8x8.h"
#include "st7735.h"

#include "esp_log.h"
#define DEBUG 0
#if DEBUG
#define DEBUG_printf(...) ESP_LOGD("st7735", __VA_ARGS__)
#else
#define DEBUG_printf(...) (void) 0
#endif


/* Font data used by _drawchar() */
typedef struct _tft_font_data {
    uint width;
    uint height;
    uint start;
    uint end;
    const uint8_t *data;
} st7735_font_data;

STATIC st7735_font_data DefaultFont = { 8, 8, 32, 127, font_petme128_8x8 };

//Set value of given pin.
STATIC void _setpin( mp_obj_t aPin, int aValue ) {
	mp_obj_t value = aValue ? mp_const_true : mp_const_false;
	machine_pin_type.call(aPin, 1, 0, &value);
}

#define CS_LOW()     _setpin(self->cs, 0);
#define CS_HIGH()    _setpin(self->cs, 1);
#define DC_LOW()     _setpin(self->dc, 0)
#define DC_HIGH()    _setpin(self->dc, 1)
#define RESET_LOW()  _setpin(self->reset, 0)
#define RESET_HIGH() _setpin(self->reset, 1)
#define LED_HIGH()   _setpin(self->led,1)
#define LED_LOW()    _setpin(self->led,0)

STATIC const uint8_t ST_Rotations[] = {0x00, 0x60, 0xC0, 0xA0 };
STATIC const uint8_t ST_BGR = 0x08;
STATIC const uint8_t ST_RGB = 0x00;

STATIC void write_spi(mp_obj_base_t *spi_obj, const uint8_t *buf, int len) {
    mp_machine_spi_p_t *spi_p = (mp_machine_spi_p_t*)spi_obj->type->protocol;
    spi_p->transfer(spi_obj, len, buf, NULL);
}

typedef struct _st7735_ST7735_obj_t {
    mp_obj_base_t base;
    mp_obj_base_t *spi_obj;
    mp_obj_t reset;
    mp_obj_t dc;
    mp_obj_t cs;
    mp_obj_t led;
    int size[2];
    int min[2];
    int dc_pin_nb,cs_pin_nb,reset_pin_nb;
    uint rotate;    //rotation 0-3
    uint rgb;       //ST_RGB or ST_BGR
    uint8_t buf[2*ST_BUFLEN];

} st7735_ST7735_obj_t;

const mp_obj_type_t st7735_ST7735_type;

STATIC void st7735_ST7735_print(const mp_print_t *print, mp_obj_t self_in, mp_print_kind_t kind) {
    (void)kind;
    st7735_ST7735_obj_t *self = MP_OBJ_TO_PTR(self_in);
    // mp_obj_type_t pin_dc = mp_obj_cast_to_native_base(self->dc, MP_OBJ_FROM_PTR(&machine_pin_type));
    if (self->reset_pin_nb == -1)
      mp_printf(print, "<ST7735 spi: %p, dc: %d, cs: %d, reset not connected>",
		self->spi_obj, self->dc_pin_nb, self -> cs_pin_nb);
    else
      mp_printf(print, "<ST7735 spi: %p, dc: %d, cs: %d, reset: %d>",
		self->spi_obj, self->dc_pin_nb, self -> cs_pin_nb, self -> reset_pin_nb);
}

STATIC mp_obj_t ST7735_make_new(const mp_obj_type_t *type, size_t n_args, size_t n_kw, const mp_obj_t *all_args) {
    enum {
	  ARG_spi, ARG_dc, ARG_cs, ARG_reset
    };

    static const mp_arg_t allowed_args[] = {
        { MP_QSTR_spi, MP_ARG_OBJ | MP_ARG_REQUIRED, {.u_obj = MP_OBJ_NULL} },
        { MP_QSTR_dc, MP_ARG_INT | MP_ARG_REQUIRED, {.u_int = 0} },
        { MP_QSTR_cs, MP_ARG_INT | MP_ARG_REQUIRED, {.u_int = 0} },
	{ MP_QSTR_reset, MP_ARG_KW_ONLY | MP_ARG_INT, {.u_int = -1} }
    };
    mp_arg_val_t args[MP_ARRAY_SIZE(allowed_args)];
    mp_arg_parse_all_kw_array(n_args, n_kw, all_args, MP_ARRAY_SIZE(allowed_args), allowed_args, args);

    /* create new object */
    st7735_ST7735_obj_t *self = m_new_obj(st7735_ST7735_obj_t);
    self->base.type = &st7735_ST7735_type;

    /* get the spi object */
    mp_obj_base_t *spi_obj = (mp_obj_base_t*)MP_OBJ_TO_PTR(args[ARG_spi].u_obj);
    self->spi_obj = spi_obj;
    
    self->size[0] = ST_WIDTH;
    self->size[1] = ST_HEIGHT;
    self->min[0] = 2;
    self->min[1] = 1;
    mp_obj_t pinargs[3];

    mp_map_t *_map = mp_obj_dict_get_map(machine_pin_type.locals_dict);
    // Output pin value.
    mp_map_elem_t *_elem = mp_map_lookup(_map, MP_OBJ_NEW_QSTR(MP_QSTR_OUT), MP_MAP_LOOKUP);
    pinargs[1] = _elem->value;
    //All pins are PULL_UP type.
    _elem = mp_map_lookup(_map, MP_OBJ_NEW_QSTR(MP_QSTR_PULL_UP), MP_MAP_LOOKUP);
    pinargs[2] = _elem->value;

    /* and the pin numbers for dc, cs and reset */
    
    self->dc_pin_nb=args[ARG_dc].u_int;
    self->cs_pin_nb=args[ARG_cs].u_int;
    self->reset_pin_nb=args[ARG_reset].u_int;
    
    pinargs[0] = MP_OBJ_NEW_SMALL_INT(self->dc_pin_nb);
    self->dc = machine_pin_type.make_new(&machine_pin_type, 3, 0, pinargs);    
    pinargs[0] = MP_OBJ_NEW_SMALL_INT(self->cs_pin_nb);
    self->cs = machine_pin_type.make_new(&machine_pin_type, 3, 0, pinargs);
    if (self->reset_pin_nb <0)
      self->reset=MP_OBJ_NULL;
    else {
      pinargs[0] = MP_OBJ_NEW_SMALL_INT(self->reset_pin_nb);
      self->reset = machine_pin_type.make_new(&machine_pin_type, 3, 0, pinargs);
    }
    
    /* the LED test */
    pinargs[0]= MP_OBJ_NEW_SMALL_INT(2);    
    self->led = machine_pin_type.make_new(&machine_pin_type, 3, 0, pinargs);

    self->rgb=1;
    self->rotate=0;

    return MP_OBJ_FROM_PTR(self);
}

STATIC void _writecommand(st7735_ST7735_obj_t *self, uint8_t aCommand) {
    DC_LOW();
    CS_LOW();
    write_spi(self->spi_obj, &aCommand, 1);
    CS_HIGH();
}

STATIC void _writedata(st7735_ST7735_obj_t *self, uint8_t *aData, uint8_t count) {
    DC_HIGH();
    CS_LOW();
    write_spi(self->spi_obj, aData, count);
    CS_HIGH();    
}

/* Clamp value between min/max */
int _clamp( int min, int max, int value ) {
    return (value < min) ? min : (value > max) ? max : value;
}

STATIC void _setwindowloc(st7735_ST7735_obj_t *self, uint8_t start_x, uint8_t start_y, uint8_t end_x, uint8_t end_y) {
    uint8_t dataA[] = {0, start_x, 0, end_x};
    DEBUG_printf("Window: start_x: %d, start_y: %d, end_x: %d, end_y: %d\n",start_x,start_y,end_x,end_y);
    _writecommand(self, ST_CASET);
    _writedata(self, dataA, sizeof(dataA));
    dataA[1] = start_y;
    dataA[3] = end_y;
    _writecommand(self, ST_RASET);
    _writedata(self, dataA, sizeof(dataA));
    _writecommand(self, ST_RAMWR);
}

/* Draw a pixel at the given position with the given color.  Color */
/*  is stored in a 2 byte array.                                   */
void _pixel( st7735_ST7735_obj_t *self, int x, int y, const uint8_t *colorA ) {
    if ((0 <= x) && (x < self->size[0]) && (0 <= y) && (y < self->size[1])) {
        _setwindowloc(self, x+self->min[0], y+self->min[1], x +self->min[0] + 1, y + self->min[1] + 1);
        _writedata(self, (uint8_t *) colorA, 2);
    }
}

/* Draw a character at the given position using the 2 byte color array.  Pixels come from */
/* the given font and are scaled by sx, sy.                                              */
void _drawchar( st7735_ST7735_obj_t *self, int x, int y, uint ci, uint8_t *colorA, st7735_font_data *font, int sx, int sy ) {

    if ((font->start <= ci) && (ci <= font->end)) {
        ci = (ci - font->start) * font->width;

        const uint8_t *charA = font->data + ci;
        if ((sx <= 1) && (sy <= 1)) {
            for (uint i = 0; i < font->width; ++i) {
                uint8_t c = *charA++;
                int cy = y;
                for (uint j = 0; j < font->height; ++j) {
                    if (c & 0x01) {
                        _pixel(self, x, cy, colorA);
                    }
                    cy += 1;
                    c >>= 1;
                }
                x += 1;
            }
        } else {
            uint numPixels = sx * sy;
            for (uint i = 0; i < font->width; ++i) {
                uint8_t c = *charA++;
                int cy = y;
                for (uint j = 0; j < font->height; ++j) {
                    if (c & 0x01) {
                        _setwindowloc(self, x, cy, x + sx - 1, cy + sy - 1);
			CS_LOW();                       // CS=0; enable SPI
			DC_HIGH();                      // DC=1; data register
                        for ( int k = 0; k < numPixels; ++k) {
			  write_spi(self->spi_obj, colorA, 2);
                        }
			CS_LOW();                       // CS=1; disable device SPI
                    }
                    cy += sy;
                    c >>= 1;
                }
                x += sx;
            }
        }
    }
}

/* Send the given color to the device for numPixels.  The color will */
/* go into the area set by a previous call to _setwindowloc          */

STATIC void _draw(st7735_ST7735_obj_t  *self, int numPixels, int color ) {
  //    printf("_draw: color: 0x%x\n",color);
    uint8_t colorA[2]= { color >> 8, color };
    for (int i=0;i<ST_BUFLEN;i++) { 
      self->buf[2*i]   = colorA[0];                  // fill the color buffer
      self->buf[2*i+1] = colorA[1];
    }
    DC_HIGH();
    CS_LOW();
    
    for (int i=0;i<numPixels/ST_BUFLEN;i++)
      write_spi(self->spi_obj, (const uint8_t *) self->buf, sizeof(uint16_t)* ST_BUFLEN);
    
    if (numPixels%ST_BUFLEN)
      write_spi(self->spi_obj, (const uint8_t *) self->buf, sizeof(uint16_t)* (numPixels%ST_BUFLEN));
    
    /*	
    for ( int i = 0; i < numPixels; ++i) {
        _writedata(self, &colorA[0], 1);
        _writedata(self, &colorA[1], 1);
    }
	*/
    CS_HIGH();    

}

/* Class methods                                    */

/* Hardware reset.                                  */
STATIC void _reset(st7735_ST7735_obj_t *self ) {
    
  //    if (self->reset == MP_OBJ_NULL)
  return;
    DC_LOW();
    RESET_HIGH();
    mp_hal_delay_us(500);
    RESET_LOW();
    mp_hal_delay_us(500);
    RESET_HIGH();
}

/* Send rotation and rgb state to device.          */
STATIC void _setMADCTL(st7735_ST7735_obj_t *self )
{
    _writecommand(self, ST_MADCTL);
    int rgb = self->rgb ? ST_RGB : ST_BGR;
    uint8_t data = ST_Rotations[self->rotate] | rgb;
    _writedata(self, &data, 1);
}
/* method led(  )                                   */
/*                                                  */
/* For testing only! Switches the builtin           */
/* led on for 500 ms                                */
/*                                                  */

STATIC mp_obj_t st7735_led(mp_obj_t self_in ) {
    st7735_ST7735_obj_t *self = MP_OBJ_TO_PTR(self_in);
    LED_HIGH();
    mp_hal_delay_ms(500);
    LED_LOW();
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(ST7735_led_obj, st7735_led);

/* method initr(  )                                 */
/*                                                  */
/* Initialize the display as a red tab version.     */
/*                                                  */
STATIC mp_obj_t st7735_initr(mp_obj_t self_in ) {
    st7735_ST7735_obj_t *self = MP_OBJ_TO_PTR(self_in);
    _reset(self);
    _writecommand(self, ST_SWRESET);
    mp_hal_delay_us(150);

    _writecommand(self, ST_SLPOUT);
    mp_hal_delay_us(500);

    byte dataA[] = {0x01, 0x2c, 0x2d, 0x01, 0x2c, 0x2d };
    _writecommand(self, ST_FRMCTR1);
    _writedata(self, dataA, 3);

    _writecommand(self, ST_FRMCTR2);
    _writedata(self, dataA, 3);

    _writecommand(self, ST_FRMCTR3);
    _writedata(self, dataA, 6);
    mp_hal_delay_us(10);

    _writecommand(self, ST_INVCTR);
    dataA[0] = 0x07;
    _writedata(self, dataA, 1);

    _writecommand(self, ST_PWCTR1);
    dataA[0] = 0xA2;
    dataA[1] = 0x02;
    dataA[2] = 0x84;
    _writedata(self, dataA, 3);

    _writecommand(self, ST_PWCTR2);
    dataA[0] = 0xC5;
    _writedata(self, dataA, 1);

    _writecommand(self, ST_PWCTR3);
    dataA[0] = 0x0A;
    dataA[1] = 0x00;
    _writedata(self, dataA, 2);

    _writecommand(self, ST_PWCTR4);
    dataA[0] = 0x8A;
    dataA[1] = 0x2A;
    _writedata(self, dataA, 2);

    _writecommand(self, ST_PWCTR5);
    dataA[0] = 0x8A;
    dataA[1] = 0xEE;
    _writedata(self, dataA, 2);

    _writecommand(self, ST_VMCTR1);
    dataA[0] = 0x0E;
    _writedata(self, dataA, 1);

    _writecommand(self, ST_INVOFF);

    _setMADCTL(self);

    _writecommand(self, ST_COLMOD);
    dataA[0] = 0x05;
    _writedata(self, dataA, 1);

    _writecommand(self, ST_CASET);
    dataA[0] = 0x00;
    dataA[1] = 0x00;    //Start x
    dataA[2] = 0x00;
    dataA[3] = self->size[0] - 1;
    _writedata(self, dataA, 4);

    _writecommand(self, ST_RASET);
    dataA[3] = self->size[1] - 1;
    _writedata(self, dataA, 4);

    const uint8_t dataGMCTRP[] = { 0x0f, 0x1a, 0x0f, 0x18, 0x2f, 0x28, 0x20, 0x22, 0x1f,
				   0x1b, 0x23, 0x37, 0x00, 0x07, 0x02, 0x10 };
    _writecommand(self, ST_GMCTRP1);
    _writedata(self, (uint8_t *)dataGMCTRP, sizeof(dataGMCTRP));

    const uint8_t dataGMCTRN[] = { 0x0f, 0x1b, 0x0f, 0x17, 0x33, 0x2c, 0x29, 0x2e, 0x30,
				   0x30, 0x39, 0x3f, 0x00, 0x07, 0x03, 0x10 };
    _writecommand(self, ST_GMCTRN1);
    _writedata(self, (uint8_t *)dataGMCTRN, sizeof(dataGMCTRN));
    mp_hal_delay_us(10);

    _writecommand(self, ST_NORON);				//Normal display on.
    mp_hal_delay_us(10);
    _writecommand(self, ST_DISPON);

    mp_hal_delay_us(100);

    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_1(ST7735_initr_obj, st7735_initr);
/*                                                  */
/* fill (colour = 0)                                */
/*                                                  */
STATIC mp_obj_t st7735_fill( mp_uint_t n_args, const mp_obj_t *args ) {
    st7735_ST7735_obj_t *self = args[0];
    int color = (n_args > 1) ? mp_obj_get_int(args[1]) : 0;

    _setwindowloc(self, 0, 0, self->size[0] - 1, self->size[1] - 1);
    int numPixels = self->size[0] * self->size[1];
    _draw(self, numPixels, color);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_fill_obj, 1, 2, st7735_fill);

/* method pixel(pos, colour)                     */
/* Set the pixel at (x, y) to the given colour.  */
/*                                               */

STATIC mp_obj_t st7735_pixel(mp_obj_t self_in, mp_obj_t pos_in, mp_obj_t color_in) {
    st7735_ST7735_obj_t *self = self_in;

    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_obj_tuple_get(pos_in, &posLen, &pos);
    int px = mp_obj_get_int(pos[0]);
    int py = mp_obj_get_int(pos[1]);
    int color = mp_obj_get_int(color_in);

    byte colorA[] = { color >> 8, color };
    _pixel(self, px, py, colorA);
    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_3(ST7735_pixel_obj, st7735_pixel);

/* method rgb(value)                                            */
/*                                                              */
/* Set tft color formar to rgb or bgr.  0 = bgr otherwise rgb.  */

STATIC mp_obj_t st7735_rgb(mp_obj_t self_in, mp_obj_t value) {
    st7735_ST7735_obj_t *self = self_in;
    bool rgb = mp_obj_is_true(value);
    if (rgb != self->rgb) {
        self->rgb = rgb;
        _setMADCTL(self);
    }
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_2(ST7735_rgb_obj, st7735_rgb);

/*                                                  */
/* method size(    )                                */
/*                                                  */
/* Return the size in (w, h) tuple.                 */

STATIC mp_obj_t st7735_size( mp_obj_t self_in ) {
    st7735_ST7735_obj_t *self = self_in;
    mp_obj_t sz[] = { mp_obj_new_int(self->size[0]), mp_obj_new_int(self->size[1]) };
    return mp_obj_new_tuple(2, sz);
}
STATIC MP_DEFINE_CONST_FUN_OBJ_1(ST7735_size_obj, st7735_size);

/* fill_rectangle [1](start, size, colour)          */
/*                                                  */
/* Fill rectangle at start for size with colour.    */
/*                                                  */
STATIC mp_obj_t st7735_fillrect( mp_uint_t n_args, const mp_obj_t *args ) {
    st7735_ST7735_obj_t *self = args[0];
    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_uint_t sizeLen;
    mp_obj_t *size;
    mp_obj_tuple_get(args[1], &posLen, &pos);
    mp_obj_tuple_get(args[2], &sizeLen, &size);

    int position_x = mp_obj_get_int(pos[0])+self->min[0];
    int position_y = mp_obj_get_int(pos[1])+self->min[1];
    int size_x = mp_obj_get_int(size[0]);
    int size_y = mp_obj_get_int(size[1]);

    int color = mp_obj_get_int(args[3]);

    position_x = _clamp(self->min[0], self->size[0], position_x);
    position_y = _clamp(self->min[1], self->size[1], position_y);
    int end_x = _clamp(self->min[0], self->size[0], position_x + size_x - 1);
    int end_y = _clamp(self->min[1], self->size[1], position_y + size_y - 1);

    if (end_x < position_x)
    {
      int tmp = end_x;
      end_x = position_x;
      position_x = tmp;
    }
    if (end_y < position_y)
    {
        int tmp = end_y;
        end_y = position_y;
        position_y = tmp;
    }

    _setwindowloc(self, position_x, position_y, end_x, end_y);
    int numPixels = ((end_x - position_x) + 1) * ((end_y - position_y) + 1);
    _draw(self, numPixels, color);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_fillrect_obj, 4, 4, st7735_fillrect);

STATIC mp_obj_t st7735_hline(size_t n_args, const mp_obj_t *args) {
    int start_x,start_y,end_x;
  //    def hline( self, aStart, aLen, aColor ) :
    st7735_ST7735_obj_t *self = MP_OBJ_TO_PTR(args[0]);
    mp_obj_tuple_t *start = MP_OBJ_TO_PTR(args[1]);
    
    DEBUG_printf("Tuple length: %d\n",start->len);
    DEBUG_printf("Tuple values: %d %d\n",mp_obj_get_int(start->items[0]),mp_obj_get_int(start->items[1]));
    
    mp_int_t length = mp_obj_get_int(args[2]);
    DEBUG_printf("Length: %d\n",length);
    mp_int_t color = mp_obj_get_int(args[3]);
    DEBUG_printf("color: %x\n",color);

    start_x = _clamp(self->min[0],  ST_WIDTH, mp_obj_get_int(start->items[0])+self->min[0]);
    start_y = _clamp(self->min[1],  ST_HEIGHT, mp_obj_get_int(start->items[1])+self->min[1]);
    DEBUG_printf("length: %d\n",length);
    end_x = _clamp(self->min[0],ST_WIDTH,start_x + length);

    if (start_x > end_x) {
      int tmp = end_x;
      end_x = start_x;
      start_x = tmp;
    }
    DEBUG_printf("hline: start_x: %d, start_y, %d, end_x: %d\n",start_x,start_y,end_x);
    _setwindowloc(self, start_x, start_y, end_x, start_y);
    _draw(self, length, color);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_hline_obj,4,4,st7735_hline);

/*  method vline(start, len, colour)                           */
/*                                                             */
/* Draw a vertical line from start for length with colour.     */
/*                                                             */
STATIC mp_obj_t st7735_vline( mp_uint_t n_args, const mp_obj_t *args ) {
    int start_x,start_y,end_y;
    st7735_ST7735_obj_t *self = MP_OBJ_TO_PTR(args[0]);
    mp_obj_tuple_t *start = MP_OBJ_TO_PTR(args[1]);

    DEBUG_printf("Tuple length: %d\n",start->len);
    DEBUG_printf("Tuple values: %d %d\n",mp_obj_get_int(start->items[0]),mp_obj_get_int(start->items[1]));
    
    mp_int_t length = mp_obj_get_int(args[2]);
    DEBUG_printf("Length: %d\n",length);
    mp_int_t color = mp_obj_get_int(args[3]);
    DEBUG_printf("color: %x\n",color);

    start_x = _clamp(self->min[0], ST_WIDTH, mp_obj_get_int(start->items[0])+self->min[0]);
    start_y = _clamp(self->min[1], ST_HEIGHT, mp_obj_get_int(start->items[1])+self->min[1]);
    end_y = _clamp(self->min[1], ST_HEIGHT,start_y + length);

    if (start_y > end_y)
    {
        int tmp = end_y;
        end_y = start_y;
        start_y = tmp;
    }

    _setwindowloc(self, start_x, start_y, start_x, end_y);
    _draw(self, length, color);
    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_vline_obj, 4, 4, st7735_vline);

/* method line(start, end, colour)                                              */
/*                                                                              */
/* Draws a line from start to end in the given colour.  Vertical or horizontal  */
/*                                                                              */
STATIC mp_obj_t st7735_line( mp_uint_t n_args, const mp_obj_t *args ) {
    st7735_ST7735_obj_t *self = args[0];
    mp_obj_t paramA[4];
    mp_uint_t posLen;
    mp_obj_t *pos;

    mp_obj_tuple_get(args[1], &posLen, &pos);
    int px = mp_obj_get_int(pos[0]);
    int py = mp_obj_get_int(pos[1]);
    mp_obj_tuple_get(args[2], &posLen, &pos);
    int ex = mp_obj_get_int(pos[0]);
    int ey = mp_obj_get_int(pos[1]);

    if (px == ex) {
        //Make sure we use the smallest y.
        paramA[0] = self;
        int len = ey - py;
        if (len < 0) {
            paramA[1] = args[2];
            paramA[2] = mp_obj_new_int(-len + 1);
        } else {
            paramA[1] = args[1];
            paramA[2] = mp_obj_new_int(len + 1);
        }
        paramA[3] = args[3];

        st7735_vline(4, paramA);
    } else if (py == ey) {
        paramA[0] = self;
        //Make sure we use the smallest x.
        int len = ex - px;
        if (len < 0) {
            paramA[1] = args[2];
            paramA[2] = mp_obj_new_int(-len + 1);
        } else {
            paramA[1] = args[1];
            paramA[2] = mp_obj_new_int(len + 1);
        }
        paramA[3] = args[3];
        st7735_hline(4, paramA);
    } else {
        int color = mp_obj_get_int(args[3]);
        byte colorA[] = { color >> 8, color };

        int dx = ex - px;
        int dy = ey - py;
        int inx = dx > 0 ? 1 : -1;
        int iny = dy > 0 ? 1 : -1;

        dx = dx >= 0 ? dx : -dx;
        dy = dy >= 0 ? dy : -dy;
        if (dx >= dy) {
            dy <<= 1;
            int e = dy - dx;
            dx <<= 1;
            while (px != ex) {
                _pixel(self, px, py, colorA);
                if (e >= 0) {
                    py += iny;
                    e -= dx;
                }
                e += dy;
                px += inx;
            }
        } else{
            dx <<= 1;
            int e = dx - dy;
            dy <<= 1;
            while (py != ey) {
                _pixel(self, px, py, colorA);
                if (e >= 0) {
                    px += inx;
                    e -= dy;
                }
                e += dx;
                py += iny;
            }
        }
    }
    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_line_obj, 4, 4, st7735_line);

/* method rect(start, size, colour)                       */
/*                                                        */
/* Draw rectangle at start for size with colour.          */
/*                                                        */

STATIC mp_obj_t st7735_rect( mp_uint_t n_args, const mp_obj_t *args ) {
    st7735_ST7735_obj_t *self = args[0];
    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_obj_t *size;
    mp_obj_tuple_get(args[1], &posLen, &pos);
    mp_obj_tuple_get(args[2], &posLen, &size);

    int position_x = mp_obj_get_int(pos[0]);
    int position_y = mp_obj_get_int(pos[1]);
    int size_x = mp_obj_get_int(size[0]);
    int size_y = mp_obj_get_int(size[1]);

    mp_obj_t r[] = { mp_obj_new_int(position_x + size_x - 1), pos[1] };
    mp_obj_t b[] = { pos[0], mp_obj_new_int(position_y + size_y - 1) };
    mp_obj_t right = mp_obj_new_tuple(posLen, r);
    mp_obj_t bottom = mp_obj_new_tuple(posLen, b);

    //pos, size.x, color
    mp_obj_t argA[4] = { self, bottom, size[0], args[3] };

    st7735_hline(4, argA);
    argA[1] = args[1];
    st7735_hline(4, argA);
    argA[2] = size[1];
    st7735_vline(4, argA);
    argA[1] = right;
    st7735_vline(4, argA);
    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_rect_obj, 4, 4, st7735_rect);

/* Key strings for font dictionaries. */
STATIC const mp_obj_t k_wobj = MP_OBJ_NEW_QSTR(MP_QSTR_Width);
STATIC const mp_obj_t k_hobj = MP_OBJ_NEW_QSTR(MP_QSTR_Height);
STATIC const mp_obj_t k_sobj = MP_OBJ_NEW_QSTR(MP_QSTR_Start);
STATIC const mp_obj_t k_eobj = MP_OBJ_NEW_QSTR(MP_QSTR_End);
STATIC const mp_obj_t k_dobj = MP_OBJ_NEW_QSTR(MP_QSTR_Data);


int absint( int v ) {
    return v < 0 ? -v : v;
}
/* method circle(start, radius, colour)       */
/*                                            */
/* Draw cricle of given radius with colour.   */
/*                                            */
STATIC mp_obj_t st7735_circle( mp_uint_t n_args, const mp_obj_t *args ) {
    st7735_ST7735_obj_t *self = args[0];
    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_obj_tuple_get(args[1], &posLen, &pos);
    int px = mp_obj_get_int(pos[0]);
    int py = mp_obj_get_int(pos[1]);
    int rad = mp_obj_get_int(args[2]);
    int color = mp_obj_get_int(args[3]);

    uint8_t colorA[] = { color >> 8, color };

    int xend = ((rad * 724) >> 10) + 1; //.7071 * 1024 = 724. >> 10 = / 1024
    float rsq = rad * rad;
    for (int x = 0; x < xend; ++x) {
        float fy = sqrtf(rsq - (float)(x * x));

        int y = (int)fy;
        int xp = px + x;
        int yp = py + y;
        int xn = px - x;
        int yn = py - y;
        int xyp = px + y;
        int yxp = py + x;
        int xyn = px - y;
        int yxn = py - x;

        _pixel(self, xp, yp, colorA);
        _pixel(self, xp, yn, colorA);
        _pixel(self, xn, yp, colorA);
        _pixel(self, xn, yn, colorA);
        _pixel(self, xyp, yxp, colorA);
        _pixel(self, xyp, yxn, colorA);
        _pixel(self, xyn, yxp, colorA);
        _pixel(self, xyn, yxn, colorA);
    }

    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_circle_obj, 4, 4, st7735_circle);

/* method fillcircle(start, radius, colour)           */
/*                                                    */
/*  Draw filled cricle of given radius with colour.   */
/*                                                    */
STATIC mp_obj_t st7735_fillcircle( mp_uint_t n_args, const mp_obj_t *args ) {
    st7735_ST7735_obj_t *self = args[0];
    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_obj_tuple_get(args[1], &posLen, &pos);
    int px = mp_obj_get_int(pos[0]);
    int py = mp_obj_get_int(pos[1]);
    int rad = mp_obj_get_int(args[2]);
    int color = mp_obj_get_int(args[3]);

    float rsq = rad * rad;

    for (int x = 0; x < rad; ++x) {
        float fy = sqrtf(rsq - (float)(x * x));
        int y = (int)fy;
        int y0 = py - y;
        int x0 = _clamp(0, self->size[0], px + x);
        int x1 = _clamp(0, self->size[0], px - x);

        int ey = _clamp(0, self->size[1], y0 + y * 2);
        y0 = _clamp(0, self->size[1], y0);
        int len = absint(ey - y0) + 1;

        _setwindowloc(self, x0, y0, x0, ey);
        _draw(self, len, color);
        _setwindowloc(self, x1, y0, x1, ey);
        _draw(self, len, color);
    }

    return mp_const_none;
}
STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_fillcircle_obj, 4, 4, st7735_fillcircle);

/* method ellipse (center_point halfaxis_a halfaxis_b,color              */
/*                                                                       */
STATIC mp_obj_t st7735_ellipse(mp_uint_t n_args, const mp_obj_t *args) {
    st7735_ST7735_obj_t *self = args[0];
    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_obj_tuple_get(args[1], &posLen, &pos);
    int x0 = mp_obj_get_int(pos[0]);
    int y0 = mp_obj_get_int(pos[1]);
    int a = mp_obj_get_int(args[2]);
    int b = mp_obj_get_int(args[2]);
    int color = mp_obj_get_int(args[4]);
    uint8_t colorA[] = { color >> 8, color };

    int a2 = a * a;
    int b2 = b * b;
    int twoa2 = a2 + a2;
    int twob2 = b2 + b2;
    int x = 0;
    int y = b;
    int px = 0;
    int py = twoa2 * y;
    // Plot initial points
    _pixel(self,x0 + x, y0 + y, colorA);
    _pixel(self,x0 - x, y0 + y, colorA);
    _pixel(self,x0 + x, y0 - y, colorA);
    _pixel(self,x0 - x, y0 - y, colorA);
    //Region 1
    int p = (int)round(b2 - (a2 * b) + (0.25 * a2));
    while (px < py) {
      x ++;
      px += twob2;
      if (p < 0)
	p += b2 + px;
      else{
	y --;
	py -= twoa2;
	p += b2 + px - py;
        _pixel(self,x0 + x, y0 + y, colorA);
	_pixel(self,x0 - x, y0 + y, colorA);
        _pixel(self,x0 + x, y0 - y, colorA);
        _pixel(self,x0 - x, y0 - y, colorA);
      }
    }
    // Region 2
    p = (int)round(b2 * (x + 0.5) * (x + 0.5) +
	      a2 * (y - 1) * (y - 1) - a2 * b2);
    while (y > 0) {
      y --;
      py -= twoa2;
      if (p > 0)
	p += a2 - py;
      else {
	x ++;
	px += twob2;
	p += a2 - py + px;
	_pixel(self,x0 + x, y0 + y, colorA);
	_pixel(self,x0 - x, y0 + y, colorA);
	_pixel(self,x0 + x, y0 - y, colorA);
	_pixel(self,x0 - x, y0 - y, colorA);
      }
    }
    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_ellipse_obj, 4, 6, st7735_ellipse);

/* method text(pos, string, color, font, size=1)                         */
/*                                                                       */
/* Write the string `str` to the screen.  It will appear immediately.    */

STATIC mp_obj_t st7735_text(mp_uint_t n_args, const mp_obj_t *args) {
    st7735_ST7735_obj_t *self = args[0];

    mp_uint_t posLen;
    mp_obj_t *pos;
    mp_obj_tuple_get(args[1], &posLen, &pos);

    uint len;
    const char *data = mp_obj_str_get_data(args[2], &len);
    int x = mp_obj_get_int(pos[0]);
    int y = mp_obj_get_int(pos[1]);
    int color = mp_obj_get_int(args[3]);
    byte colorA[] = { color >> 8, color };
    uint sx = 1;
    uint sy = 1;

    st7735_font_data font;
    bool bfontSet = false;

    //If font is given then read the data from the font dict.
    if (n_args >= 5) {
        if (MP_OBJ_IS_TYPE(args[4], &mp_type_dict)) {
            mp_obj_dict_t *fontd = args[4];
            mp_obj_t arg = mp_obj_dict_get(fontd, k_wobj);
            if (arg != MP_OBJ_NULL) {
                font.width = mp_obj_get_int(arg);
                arg = mp_obj_dict_get(fontd, k_hobj);
                if (arg != MP_OBJ_NULL) {
                    font.height = mp_obj_get_int(arg);
                    arg = mp_obj_dict_get(fontd, k_sobj);
                    if (arg != MP_OBJ_NULL) {
                        font.start = mp_obj_get_int(arg);
                        arg = mp_obj_dict_get(fontd, k_eobj);
                        if (arg != MP_OBJ_NULL) {
                            font.end = mp_obj_get_int(arg);
                            arg = mp_obj_dict_get(fontd, k_dobj);
                            if (arg != MP_OBJ_NULL) {
                                mp_buffer_info_t bufinfo;
                                mp_get_buffer(arg, &bufinfo, MP_BUFFER_READ);
                                font.data = bufinfo.buf;
                                bfontSet = true;
                            }
                        }
                    }
                }
            }
        }

        /* If size value given get data from either tuple or single integer. */
        if (n_args >= 6) {
            if (MP_OBJ_IS_TYPE(args[5], &mp_type_tuple)) {
                mp_obj_t *fsize;
                mp_obj_tuple_get(args[5], &posLen, &fsize);
                sx = mp_obj_get_int(fsize[0]);
                sy = mp_obj_get_int(fsize[1]);
            } else if (MP_OBJ_IS_INT(args[5])) {
                sx = mp_obj_get_int(args[5]);
                sy = sx;
            }
        }
    }

    /* If no font set use the default. */
    if (!bfontSet) font = DefaultFont;

    int px = x;
    uint width = font.width * sx;
    uint height = font.height * sy + 1;    //Add 1 to keep lines separated by 1 line.
    for (uint i = 0; i < len; ++i) {
        _drawchar(self, px, y, *data++, colorA, &font, sx, sy);
        px += width;
        if (px + width > self->size[0]) {
            y += height;
            if (y > self->size[1]) break;
            px = x;
        }
    }

    return mp_const_none;
}

STATIC MP_DEFINE_CONST_FUN_OBJ_VAR_BETWEEN(ST7735_text_obj, 4, 6, st7735_text);

STATIC const mp_rom_map_elem_t ST7735_locals_dict_table[] = {
    { MP_ROM_QSTR(MP_QSTR_initr), MP_ROM_PTR(&ST7735_initr_obj) },
    { MP_ROM_QSTR(MP_QSTR_led), MP_ROM_PTR(&ST7735_led_obj) },
    { MP_ROM_QSTR(MP_QSTR_hline), MP_ROM_PTR(&ST7735_hline_obj) },
    { MP_ROM_QSTR(MP_QSTR_vline), MP_ROM_PTR(&ST7735_vline_obj) },
    { MP_ROM_QSTR(MP_QSTR_line), MP_ROM_PTR(&ST7735_line_obj) },
    { MP_ROM_QSTR(MP_QSTR_fill), MP_ROM_PTR(&ST7735_fill_obj) },
    { MP_ROM_QSTR(MP_QSTR_rect), MP_ROM_PTR(&ST7735_rect_obj) },
    { MP_ROM_QSTR(MP_QSTR_fillrect), MP_ROM_PTR(&ST7735_fillrect_obj) },
    { MP_ROM_QSTR(MP_QSTR_circle), MP_ROM_PTR(&ST7735_circle_obj) },
    { MP_ROM_QSTR(MP_QSTR_fillcircle), MP_ROM_PTR(&ST7735_fillcircle_obj) },
    { MP_ROM_QSTR(MP_QSTR_ellipse), MP_ROM_PTR(&ST7735_ellipse_obj) },
    { MP_ROM_QSTR(MP_QSTR_size), MP_ROM_PTR(&ST7735_size_obj) },
    { MP_ROM_QSTR(MP_QSTR_rgb), MP_ROM_PTR(&ST7735_rgb_obj) },
    { MP_ROM_QSTR(MP_QSTR_text), MP_ROM_PTR(&ST7735_text_obj) },
    { MP_ROM_QSTR(MP_QSTR_pixel), MP_ROM_PTR(&ST7735_pixel_obj) },
        //class constants
    { MP_ROM_QSTR(MP_QSTR_BLACK), MP_ROM_INT(ST_COLOR_BLACK) },
    { MP_ROM_QSTR(MP_QSTR_NAVY), MP_ROM_INT(ST_COLOR_NAVY) },
    { MP_ROM_QSTR(MP_QSTR_DARKGREEN), MP_ROM_INT(ST_COLOR_DARKGREEN) },
    { MP_ROM_QSTR(MP_QSTR_DARKCYAN), MP_ROM_INT(ST_COLOR_DARKCYAN) },
    { MP_ROM_QSTR(MP_QSTR_MAROON), MP_ROM_INT(ST_COLOR_MAROON) },
    { MP_ROM_QSTR(MP_QSTR_PURPLE), MP_ROM_INT(ST_COLOR_PURPLE) },
    { MP_ROM_QSTR(MP_QSTR_OLIVE), MP_ROM_INT(ST_COLOR_OLIVE) },
    { MP_ROM_QSTR(MP_QSTR_LIGHTGREY), MP_ROM_INT(ST_COLOR_LIGHTGREY) },
    { MP_ROM_QSTR(MP_QSTR_DARKGREY), MP_ROM_INT(ST_COLOR_DARKGREY) },
    { MP_ROM_QSTR(MP_QSTR_BLUE), MP_ROM_INT(ST_COLOR_BLUE) },
    { MP_ROM_QSTR(MP_QSTR_GREEN), MP_ROM_INT(ST_COLOR_GREEN) },
    { MP_ROM_QSTR(MP_QSTR_CYAN), MP_ROM_INT(ST_COLOR_CYAN) },
    { MP_ROM_QSTR(MP_QSTR_RED), MP_ROM_INT(ST_COLOR_RED) },
    { MP_ROM_QSTR(MP_QSTR_MAGENTA), MP_ROM_INT(ST_COLOR_MAGENTA) },
    { MP_ROM_QSTR(MP_QSTR_YELLOW), MP_ROM_INT(ST_COLOR_YELLOW) },
    { MP_ROM_QSTR(MP_QSTR_WHITE), MP_ROM_INT(ST_COLOR_WHITE) },
    { MP_ROM_QSTR(MP_QSTR_ORANGE), MP_ROM_INT(ST_COLOR_ORANGE) },
    { MP_ROM_QSTR(MP_QSTR_GREENYELLOW), MP_ROM_INT(ST_COLOR_GREENYELLOW) },
    { MP_ROM_QSTR(MP_QSTR_PINK), MP_ROM_INT(ST_COLOR_PINK) },
    { MP_ROM_QSTR(MP_QSTR_FOREST), MP_ROM_INT(ST_COLOR_FOREST) },
    { MP_ROM_QSTR(MP_QSTR_RGB), MP_ROM_FALSE },
    { MP_ROM_QSTR(MP_QSTR_BGR), MP_ROM_TRUE },
};

STATIC MP_DEFINE_CONST_DICT(ST7735_locals_dict, ST7735_locals_dict_table);

const mp_obj_type_t st7735_ST7735_type = {
    { &mp_type_type },
    .name = MP_QSTR_st7735,
    .print = st7735_ST7735_print,
    .make_new = ST7735_make_new,
    .locals_dict = (mp_obj_dict_t*)&ST7735_locals_dict,
};

STATIC const mp_map_elem_t st7735_globals_table[] = {
    { MP_OBJ_NEW_QSTR(MP_QSTR___name__), MP_OBJ_NEW_QSTR(MP_QSTR_st7735) },
    { MP_OBJ_NEW_QSTR(MP_QSTR_ST7735), (mp_obj_t)&st7735_ST7735_type },	
    { MP_OBJ_NEW_QSTR(MP_QSTR_hline), (mp_obj_t)&ST7735_hline_obj },
};

STATIC MP_DEFINE_CONST_DICT (
    mp_module_st7735_globals,
    st7735_globals_table
);

const mp_obj_module_t st7735_user_cmodule = {
    .base = { &mp_type_module },
    .globals = (mp_obj_dict_t*)&mp_module_st7735_globals,
};

MP_REGISTER_MODULE(MP_QSTR_st7735, st7735_user_cmodule, MODULE_ST7735_ENABLED);
